﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


//Control the flow of the game
public class GameControl : MonoBehaviour
{
    public static GameObject player1;
    public static GameObject turnsObject;
    public static GameObject turnsCurrencyObject;
    public static GameObject YouLosePanel;
    public static GameObject YouWinPanel;
    public static GameObject CardPanel;
    public static GameObject CardText;
    public static GameObject deckObject;

    [SerializeField]
    public static int rolledDiceSide = 0;
    public int StartWayPoint = 0;

   
    public static int turns = 0;
    public static int turn_currency = 10;
    
    public int mycard_currency;
    public int mycard_spaces;


    // Used for initialization
    void Start()
    {
        player1 = GameObject.Find("player1");

        //Finds all UI texts
        turnsObject = GameObject.Find("Turns");
        turnsCurrencyObject = GameObject.Find("Turn_Currency");
        YouLosePanel = GameObject.Find("YouLosePanel");
        YouWinPanel = GameObject.Find("YouWinPanel");
        CardPanel = GameObject.Find("CardPanel");
        CardText = GameObject.Find("CardText");
        deckObject = GameObject.Find("Deck");


        turnsObject.GetComponent<Text>().text = "TURNS: " + turns;
        turnsCurrencyObject.GetComponent<Text>().text = "TURNS CURRENCY: " + turn_currency;
        YouLosePanel.gameObject.SetActive(false);
        YouWinPanel.gameObject.SetActive(false);
        CardPanel.gameObject.SetActive(false);

    }

    // Update is called once per frame
    void Update()
    {
        
        //Moves player through spaces until it has reach the rolled space, if not the player will keep moving
        if (player1.GetComponent<FollowPath>().wayPointIndex > (StartWayPoint + rolledDiceSide))
        {
           
            //Makes the player stop moving
            player1.GetComponent<FollowPath>().moveAllowed = false;
            //Updates player coordinates
            StartWayPoint = player1.GetComponent<FollowPath>().wayPointIndex - 1;

            drawCard();

            turn_currency -= 2;

            //Updates turns and turn currency
            turnsObject.GetComponent<Text>().text = "TURNS: " + turns;
            turnsCurrencyObject.GetComponent<Text>().text = "TURNS CURRENCY: " + turn_currency;
    
        }
        //Display Winner prompt
        else if(player1.GetComponent<FollowPath>().wayPointIndex == player1.GetComponent<FollowPath>().wayPoints.Length)
        {
            
            //Updates player coordinates
            StartWayPoint = player1.GetComponent<FollowPath>().wayPointIndex - 1;
            //shows winner panel
            YouWinPanel.gameObject.SetActive(true);

            //Updates turns and turn currency
            turnsObject.GetComponent<Text>().text = "TURNS: " + turns;
            turnsCurrencyObject.GetComponent<Text>().text = "TURNS CURRENCY: " + turn_currency;

        }
        else if ((turn_currency == 0 || turn_currency == 1) && player1.GetComponent<FollowPath>().wayPointIndex != player1.GetComponent<FollowPath>().wayPoints.Length)
        {
            //Updates turns and turn currency
            turnsObject.GetComponent<Text>().text = "TURNS: " + turns;
            turnsCurrencyObject.GetComponent<Text>().text = "TURNS CURRENCY: " + turn_currency;
            //Updates player coordinates
            StartWayPoint = player1.GetComponent<FollowPath>().wayPointIndex - 1;
            //shows loser panel
            YouLosePanel.gameObject.SetActive(true);
        }
        
          
    }

    public static void MovePlayer()
    {
     
     player1.GetComponent<FollowPath>().moveAllowed = true;
     turns += 1;

    }

   

    public void drawCard()
    {

        Card mycard = new Card();
        mycard = deckObject.GetComponent<Deck>().shuffledDeck[StartWayPoint];
        mycard_currency = mycard.currency;
        mycard_spaces = mycard.spaces;

        CardText.GetComponent<Text>().text = "You landed on a bonus! Currency: " + mycard_currency + " Spaces: " + mycard_spaces;
        CardPanel.gameObject.SetActive(true);
        StartCoroutine(showCardPanel());
        

    }
    IEnumerator showCardPanel()
    {


        yield return new WaitForSeconds(3);

        CardPanel.gameObject.SetActive(false);

    }
}
