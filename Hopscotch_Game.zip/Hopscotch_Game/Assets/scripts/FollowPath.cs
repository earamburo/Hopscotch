﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FollowPath : MonoBehaviour
{

    public Transform[] wayPoints;

    [SerializeField]
    private float moveSpeed = 1f;

    //[HideInInspector]
    public int wayPointIndex = 0;

    public bool moveAllowed = false;

    public GameObject bonusPanel;


    //Use for initialization. Start point for players
    void Start()
    {
        transform.position = wayPoints[wayPointIndex].transform.position;
    }

    void Update()
    {
        if (moveAllowed)
        {
            Move();
            

        }

    }
    void Move()
    {
        //Checks the position of the player and moves them accordingly
        if(wayPointIndex <= wayPoints.Length - 1)
        {
            transform.position = Vector2.MoveTowards(transform.position, wayPoints[wayPointIndex].transform.position, moveSpeed * Time.deltaTime);


            //updates way point index from old to new until move is not allowed any longer
            if (transform.position == wayPoints[wayPointIndex].transform.position)
            {
                wayPointIndex += 1;
            }
        }
        
    }
}