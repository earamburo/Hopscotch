﻿//using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyDice : MonoBehaviour
{
    //Array for all the sides on a dice
    private static Sprite[] diceSides;
    //Used to change dice image
    private static SpriteRenderer rend;
    

    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<SpriteRenderer>();
        diceSides = Resources.LoadAll<Sprite>("sprites/dice_sides");
        rend.sprite = diceSides[2];
    }

    //Handles when the dice is clicked on
    void OnMouseDown()
    {
       
        StartCoroutine(Roll());
        
    }


    //Rolls the dice and diplays the new rolled number
    static IEnumerator Roll()
    {
        int randomDiceSide = 0;

        //Selects random number for the dice value
        for (int i = 0; i <= 10; i++)
        {
            //Picks a number b/w 0-2
            randomDiceSide = Random.Range(0, 3);
            rend.sprite = diceSides[randomDiceSide];

            yield return new WaitForSeconds(0.05f);
        }

        GameControl.rolledDiceSide = randomDiceSide + 1;
        GameControl.MovePlayer();
      

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
