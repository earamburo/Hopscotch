﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;

public class Deck : MonoBehaviour
{
    public Deck mydeck;

    [SerializeField]
    //empty deck
    public Card[] shuffledDeck = new Card[9];

    //card objects got added via Unity MAKE SURE NOT TO RESET the Deck component
    public Card[] masterOrderedDeck = new Card[9];



    int random_num;
    int count;
    int fail_count;

    System.Random r = new System.Random();


    public void SelectRandomCard()
    {
        count++;

        random_num = r.Next(10);

        //Console.WriteLine(random_num);

        if (CheckRandomSelection(random_num))
        {
            fail_count = 0;
            return;
        }
        else
        {
            fail_count++;
            SelectRandomCard();
        }


    }


    public bool CheckRandomSelection(int elem)
    {
        if (!masterOrderedDeck[elem].isUsed)
        {
            masterOrderedDeck[elem].isUsed = true;
            return true;
        }
        else
        {
            return false;
        }

    }
    public Card InsertRandomCard()
    {
        //Empty card
        Card random_card = new Card();

        SelectRandomCard();


        random_card = masterOrderedDeck[random_num];

        return random_card;
    }
    void Shuffle()
    {
        shuffledDeck[0] = InsertRandomCard();
        shuffledDeck[1] = InsertRandomCard();
        shuffledDeck[2] = InsertRandomCard();
        shuffledDeck[3] = InsertRandomCard();
        shuffledDeck[4] = InsertRandomCard();
        shuffledDeck[5] = InsertRandomCard();
        shuffledDeck[6] = InsertRandomCard();
        shuffledDeck[7] = InsertRandomCard();
        shuffledDeck[8] = InsertRandomCard();
        shuffledDeck[9] = InsertRandomCard();
    }


    // Use this for initialization
    void Start()
    {
        
        Shuffle();


    }
    // Update is called once per frame
    void Update()
    {

    }
}
