﻿using UnityEngine;
using System.Collections;

public class Card : MonoBehaviour
{

    public int currency = 0;
    public int spaces = 0;
    public bool isUsed = false;
    public Card mycard;

    public Card()
    {
        currency = 0;
        spaces = 0;
        isUsed = false;
    }

    public Card(int curr, int sp)
    {
        curr = currency;
        sp = spaces;
    }
    // Use this for initialization
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {

    }
}
